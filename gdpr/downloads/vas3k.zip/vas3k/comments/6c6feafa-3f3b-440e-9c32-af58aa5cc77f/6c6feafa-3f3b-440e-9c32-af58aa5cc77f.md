[Survive the Internet](https://www.jackboxgames.com/survive-the-internet/) is funny too, here's a gameplay video for example

https://www.youtube.com/watch?v=z2KMYbx6rVs&feature=youtu.be

- vas3k